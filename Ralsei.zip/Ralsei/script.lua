
-- hide vanilla model
vanilla_model.ALL:setVisible(false)
vanilla_model.HELD_ITEMS:setVisible(false)

-- remove shadow and nametag
renderer:setShadowRadius(0)
nameplate.Entity:setVisible(host:isHost())

local hide_ticks = 0
local hiding = false
local chars_delay = 1
local chars_delay_countdown = 0
local current_msg_len = 0
local g_msg = ""
local icon = 0
local current_char = 0
local color_words = {
    ["yellow"] = "#fff200",
    ["minecraft"] = "#fff200",
    ["star"] = "#fff200",
    ["ralsei"] = "#fff200",
    ["join"] = "#fff200",
    ["bird"] = "#fff200",
    ["key"] = "#fff200",
    ["item"] = "#fff200",
    ["cool"] = "#fff200",
    ["piss"] = "#fff200",
    ["gold"] = "#fff200",
    ["must"] = "#fff200",
    ["ball"] = "#fff200",
    ["love"] = "#fff200",
    ["much"] = "#fff200",
    ["depress"] = "#fff200",
    ["big"] = "#fff200",
    ["shot"] = "#fff200",
    ["definitely"] = "#fff200",
    ["fabulous"] = "#fff200",
    ["red"] = "#ff0000",
    ["genocide"] = "#ff0000",
    ["hate"] = "#ff0000",
    ["redstone"] = "#ff0000",
    ["blood"] = "#ff0000",
    ["orange"] = "#fca600",
    ["copper"] = "#fca600",
    ["green"] = "#00c000",
    ["emerald"] = "#00c000",
    ["moss"] = "#00c000",
    ["cyan"] = "#40fcff",
    ["aqua"] = "#40fcff",
    ["pacifist"] = "#40fcff",
    ["diamond"] = "#40fcff",
    ["blue"] = "#003cff",
    ["water"] = "#003cff",
    ["rain"] = "#003cff",
    ["lapis"] = "#003cff",
    ["navy"] = "#023542",
    ["sculk"] = "#023542",
    ["purple"] = "#d535d9",
    ["amethyst"] = "#d535d9",
    ["spider"] = "#d535d9",
    ["pink"] = "#FC68B2"
}

-- returns the number of UTF-8 characters in a string
local function utf8_len(str)
    local _, count = string.gsub(str, "[^\128-\191]", "")
    return count
end

-- determines how many bytes a UTF-8 character takes based on the first byte
local function utf8_char_len(c)
    if c < 0x80 then
        return 1
    elseif c < 0xE0 then
        return 2
    elseif c < 0xF0 then
        return 3
    else
        return 4
    end
end

-- returns the Nth UTF-8 character from the end of the string
local function utf8_nth_from_end(str, n)
    local i = #str
    local count = 0

    while i > 0 do
        local c = str:byte(i)
        if c < 0x80 or c >= 0xC0 then
            count = count + 1
            if count == n then
                return str:sub(i, i + utf8_char_len(c) - 1)
            end
        end
        i = i - 1
    end

    return ""
end

-- Returns a substring of the first N UTF-8 characters
local function utf8_sub(str, n)
    local i = 1
    local len = 0

    while i <= #str do
        len = len + 1
        if len > n then
            return str:sub(1, i - 1)
        end

        local c = str:byte(i)
        if c < 0x80 then
            i = i + 1
        elseif c < 0xE0 then
            i = i + 2
        elseif c < 0xF0 then
            i = i + 3
        else
            i = i + 4
        end
    end

    return str
end


local function truncate_color_json(text, max_chars)
    local segments = {}
    local last_end = 1

    while true do
        local s, e = string.find(text, "%S+", last_end)
        if not s then break end

        local prefix = text:sub(last_end, s - 1)
        local word   = text:sub(s, e)

        if #segments == 0 then
            -- always start with a text segment
            table.insert(segments, { type = "text", text = "" })
        end

        if prefix ~= "" then
            table.insert(segments, { type = "text", text = prefix })
        elseif color_words[word] and #segments == 0 then
            -- if the message starts with a color word, make sure we start the JSON with a text segment first
            table.insert(segments, { type = "text", text = "" })
        end
        
        -- matcher
        local word_lower = word:lower()
        local is_asterisked = word:sub(1,1) == "*" and word:sub(-1) == "*" and #word > 2

        if is_asterisked then
            -- override the color with yellow if the word is surrounded by asterisks *
            word = word:sub(2, -2)
            table.insert(segments, {
                type  = "color",
                text  = word,
                color = "#fff200"
            })
        else
            local match_color = nil
            local longest_match = 0

            for key, color in pairs(color_words) do
                -- only match whole word parts (like "star" in "starwalker", but not "i" in "pink")
                if word_lower:sub(1, #key) == key and #key > longest_match then
                    match_color = color
                    longest_match = #key
                end
            end

            if match_color then
                table.insert(segments, {
                    type  = "color",
                    text  = word,
                    color = match_color
                })
            else
                table.insert(segments, { type = "text", text = word })
            end
        end

        last_end = e + 1
    end

    local suffix = text:sub(last_end)
    if suffix ~= "" then
        table.insert(segments, { type = "text", text = suffix })
    end

    local used = 0
    local out_segs = {}

    for _, seg in ipairs(segments) do
        local seg_len = utf8_len(seg.text) or 0

        if used + seg_len < max_chars then
            table.insert(out_segs, seg)
            used = used + seg_len
        else
            local remaining = max_chars - used
            if remaining > 0 then
                local part = utf8_sub(seg.text, remaining)
                if seg.type == "color" then
                    table.insert(out_segs, {
                        type  = "color",
                        text  = part,
                        color = seg.color
                    })
                else
                    table.insert(out_segs, { type = "text", text = part })
                end
                used = used + remaining
            end
            break
        end
    end

    local parts = {}
    for _, seg in ipairs(out_segs) do
        if seg.type == "text" then
            table.insert(parts, string.format("%q", seg.text))
        else
            table.insert(parts, string.format(
                "{\"text\":%q,\"color\":%q}",
                seg.text,
                seg.color
            ))
        end
    end

    return "[" .. table.concat(parts, ",") .. "]"
end

function events.tick()
    if current_char < current_msg_len then
        chars_delay_countdown = chars_delay_countdown + 1

        if chars_delay_countdown == chars_delay then
            current_char = current_char + 1

            -- generate a new dynamic text element
            local nameText = models.model.root.text:newText("dynamic_text")
            local msg = truncate_color_json(g_msg, current_char)

            -- set up the new partial message
            nameText:setText(msg)
                    :setPos(-13, 0, 0)
                    :setScale(0.3)
                    :setAlignment("LEFT")
                    :setWidth(90)
                    :setLight(15, 15)

            -- reset delay countdown
            chars_delay_countdown = 0

            -- if the last char wasn't a space, play the voice
            local last_char = utf8_nth_from_end(msg, 3)
            if last_char ~= " " then
                sounds:playSound("voice", player:getPos())
            end
        end
    elseif models.model.root.textbox:getVisible() and (not hiding) then
        hiding = true
        hide_ticks = 75  -- start countdown to hide
    end

    if hiding then
        hide_ticks = hide_ticks - 1
        if hide_ticks == 0 then
            models.model.root.textbox:setVisible(false)
            models.model.root.icon:setVisible(false)
            models.model.root.text:setVisible(false)
            hiding = false
        end
    end
end

function pings.chat_msg(msg)
    g_msg = msg
    current_msg_len = utf8_len(msg)
    chars_delay_countdown = 0
    current_char = 0
    hiding = false
    hide_ticks = 75

    -- show text UI
    models.model.root.textbox:setVisible(true)
    models.model.root.icon:setUVPixels(icon * 49,0)
    models.model.root.icon:setVisible(true)
    models.model.root.text:setVisible(true)
end

function events.chat_send_message(msg)
    -- if it's a command (starts with /), don't intercept
    if msg:sub(1, 1) == "/" or msg:sub(1, 1) == " " or msg:sub(1, 1) == "!" then
        return msg
    else
        if msg:sub(1, 1) == "&" and tonumber(msg:sub(2, 2)) < 10 then
            icon = tonumber(msg:sub(2, 2))
            pings.chat_msg(msg:sub(3, -1))
            return failed
        end
        -- otherwise, send message to the ping function
        icon = 1
        pings.chat_msg(msg)
    end
end

function events.skull_render(delta,block,item,entity,mode)
    -- switches between the block and hat versions of mini starwalker
    if mode == "HEAD" then
        models.model.root.Skull.Block:setVisible(false)
        models.model.root.Skull.Hat:setVisible(true)
    else
        models.model.root.Skull.Block:setVisible(true)
        models.model.root.Skull.Hat:setVisible(false)
    end
end