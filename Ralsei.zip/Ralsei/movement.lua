local UVx = 0
local UVy = 0
local SpriteSize = 32
local SpriteCount = 4
local SpriteDelay = 2
local SpriteTimer = 0
local Sprite = 0
SpecialState = "none"

models.model.root.ralsei:setScale(0.7,0.7,0.7)

local function getDir()
    local viewerAng = (client:getViewer():getRot()[2] + 360) % 360
    local playerAng = (player:getRot()[2] + 360) % 360
    local angDiff = (playerAng - viewerAng + 360) % 360
    if angDiff <= 45 or angDiff > 315 then return "backward"
    elseif angDiff >= 45 and angDiff < 135 then return "left"
    elseif angDiff >= 135 and angDiff < 225 then return "forward"
    else return "right" end
end

local function anim(pos, dx, dy, size, count, delay)
    models.model.root.ralsei:setPos(pos)
    UVx = dx
    UVy = dy
    SpriteSize = size
    SpriteCount = count
    SpriteDelay = delay
end

local function special()
    if SpecialState == "aura" then anim(vec(0, 1, 0), 0, 156, 78, 4, 3)
    elseif SpecialState == "squished" then anim(vec(0, 1, 0), 468, 156, 78, 0, 2)
    elseif SpecialState == "horse" then
        if player:isMoving() then anim(vec(10, 1, 0), 0, 0, 78, 8, 1)
        else anim(vec(10, 1, 0), 312, 156, 78, 0, 2) end
    end
end

events.RENDER:register(function(d)
    local cameraRot = client:getCameraRot()

    -- if in first-person view, don't rotate at all
    if renderer:isFirstPerson() then
        cameraRot = vec(0, 0, 0)
    end

    local i = cameraRot.y - player:getBodyYaw(d)

    -- rotate the model to face the camera
    models.model:setRot(0, -i, 0)
    if SpecialState == "squished" then models.model.root:setRot(70, 180, 0)
    else models.model.root:setRot(0, 180, 0) end
end)

local fall = false
local noAnimTicks = 0
local idleTimer = 0
function events.tick()

    if SpecialState ~= "none" then special()
    elseif noAnimTicks ~= 0 then
        noAnimTicks = noAnimTicks - 1
        idleTimer = 2

    elseif player:getVelocity()[2] < -0.4 then
        anim(vec(0, 0, 0), 128, 42, 32, 0, 2)
        fall = true
        idleTimer = 20
        
    elseif not player:isFalling() and fall then
        anim(vec(0, 0, 0), 128, 0, 32, 0, 2)
        fall = false
        idleTimer = 20
    
    elseif player:isBlocking() then
        if UVy ~= 104 or SpriteSize == 32 then 
            anim(vec(0, 0, 0), 0, 104, 78, 8, 1)
            Sprite = 0
            idleTimer = 2 end

    elseif player:isSneaking() then
        local dir = getDir()
        idleTimer = 20
        if dir == "forward" or dir == "right" then anim(vec(0, 3, 0), 0, 210, 32, 4, 5)
        else anim(vec(0, 3, 0), 0, 168, 32, 4, 5) end

    elseif math.abs(player:getVelocity()[1]) + math.abs(player:getVelocity()[3]) > 0.16 then
        local dir = getDir()
        idleTimer = 20
        if player:isSprinting() then
            if dir == "forward" then anim(vec(0, 0, 0), 0, 294, 32, 4, 2)
            elseif dir == "right" then anim(vec(0, 0, 0), 0, 336, 32, 4, 2)
            elseif dir == "left" then anim(vec(0, 0, 0), 0, 378, 32, 4, 2)
            else anim(vec(0, 0, 0), 0, 420, 32, 4, 2) end
        else
            if dir == "forward" then anim(vec(0, 0, 0), 0, 0, 32, 4, 2)
            elseif dir == "right" then anim(vec(0, 0, 0), 0, 42, 32, 4, 2)
            elseif dir == "left" then anim(vec(0, 0, 0), 0, 84, 32, 4, 2)
            else anim(vec(0, 0, 0), 0, 126, 32, 4, 2) end
        end

    else
        if idleTimer == 0 then
            anim(vec(0, 0, 0), 0, 252, 32, 5, 3)
        else idleTimer = idleTimer - 1 end
    end

    if SpriteTimer >= SpriteDelay then
        Sprite = Sprite + 1
        if Sprite >= SpriteCount then
            if UVy == 104 and SpriteSize == 78 then Sprite = 7
            else Sprite = 0 end
        end
        if SpriteSize == 32 then
            models.model.root.ralsei.idle:setUVPixels(SpriteSize * Sprite + UVx,UVy)
            models.model.root.ralsei.idle_big:setVisible(false)
            models.model.root.ralsei.idle:setVisible(true)
        else
            models.model.root.ralsei.idle_big:setUVPixels(SpriteSize * Sprite + UVx,UVy)
            models.model.root.ralsei.idle:setVisible(false)
            models.model.root.ralsei.idle_big:setVisible(true) end
        SpriteTimer = 0
    else SpriteTimer = SpriteTimer + 1 end
end

function events.DAMAGE()
    sounds:playSound("damage", player:getPos())
    noAnimTicks = 11
    anim(vec(0, 0, 0), 128, 84, 32, 0, 2)
end

function events.MOUSE_PRESS(button, action)
    if button == 0 and action == 1 and player:getTargetedEntity() ~= nil then
        if noAnimTicks == 0 then
            noAnimTicks = 12
            Sprite = 0
            anim(vec(0, 0, 0), 0, 52, 78, 8, 1)
        end
    end
end

function events.ON_PLAY_SOUND(id, pos, vol, pitch, path)
    if not path then return end              --dont trigger if the sound was played by figura (prevent potential infinite loop)
    if not player:isLoaded() then return end -- dont do anything if the player isn't loaded

    local distance = (player:getPos() - pos):length()
    if distance > 0.2 then return end                                 -- make sure the sound is (most likely) played by *you*. Larger radius captures uncommon sounds with random placement
    if id:find("fall") or id:find("hurt") then                                           -- if sound contains ".eat"
        sounds:playSound("damage", pos, vol, pitch) -- play a custom sound
        return true end
end
