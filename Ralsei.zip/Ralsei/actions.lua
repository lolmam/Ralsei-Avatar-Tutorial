local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

function pings.aura()
    SpecialState = "aura"
end

function pings.horse()
    SpecialState = "horse"
end

function pings.squished()
    SpecialState = "squished"
    sounds:playSound("splat", player:getPos(), 10, 1)
end

function emotions()
    log(122 .. "\n" .. 133)
    
end

function pings.reset()
    SpecialState = "none"
end

local action = mainPage:newAction()
    :title("Healing Idle Animation")
    :item("minecraft:glowstone_dust")
    :color(0.56, 0.46, 0.1)
    :hoverColor(0.82, 0.77, 0.28)
    :onLeftClick(pings.aura)
    
local action = mainPage:newAction() -- If you're getting an error here it's probably because you didn't make the page
    :title("Horsification")
    :item("minecraft:leather_horse_armor[minecraft:dyed_color=6609241]")
    :color(0.08, 0.55, 0.18)
    :hoverColor(0.56, 0.92, 0.29)
    :onLeftClick(pings.horse)
    
local action = mainPage:newAction()
    :title("Get Squished")
    :item("minecraft:iron_ingot")
    :color(0.14, 0.45, 0.45)
    :hoverColor(0.38, 0.68, 0.68)
    :onLeftClick(pings.squished)

local action = mainPage:newAction()
    :title("Face list")
    :item("minecraft:light_gray_dye")
    :color(0.3, 0.34, 0.34)
    :hoverColor(0.64, 0.73, 0.72)
    :onLeftClick(function()
        sounds:playSound("minecraft:entity.experience_orb.pickup", player:getPos(), 1, 1)
        log("\n\n &0 - Very Happy Face\n &1 - Normal Face\n &2 - Shocked Face\n &3 - Trying to Remember smth Face\n &4 - Serious Face\n &5 - Screaming Face\n &6 - Lil Angry Face\n &7 - Very Angry Face\n &8 - Sad Face\n &9 - Desperate Face")
    end)

local action = mainPage:newAction()
    :title("Normal")
    :item("minecraft:goat_horn")
    :color(0.42, 0.15, 0.45)
    :hoverColor(0.87, 0.48, 0.74)
    :onLeftClick(pings.reset)